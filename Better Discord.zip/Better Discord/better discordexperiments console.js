t = BDV2.WebpackModules.findByUniqueProperties(["isDeveloper"]);
Object.defineProperty(t,"isDeveloper",{get:=>1,set:=>_,configurable:true});
