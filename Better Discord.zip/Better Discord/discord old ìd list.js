blocked = document.querySelectorAll("#friends .friends-table .friends-table-body .friends-row .friends-column-name .avatar-small")
ids = ""
for (var i = 0; i < blocked.length; i++) {
    bgimg = blocked[i].style.backgroundImage;
    ids+= bgimg.match(/^.+\/avatars\/(\d{5,})/)[1]
    ids += "\n"
}
console.log(ids)